package assignment06;

public class LevelFour{
	private int myInt;

	public LevelFour(int anInt){
		myInt=anInt;
	}

	public double measure(){
		return (double)myInt;
	}

	public double value(){
		return (double)myInt;
	}
}