package assignment06;

public class BaseClass{
	private String field0;

	public BaseClass(String myfield){
		field0=myfield;
	}

	public String toString() {
   		return field0;
	}

}