package assignment01;

public class HighSchool {

	private String name;

	public HighSchool(String aName) {
		name=aName;
	}//end of constructor

	public String getName(){
		return name;
	}//end of getName
}//end of HighSchool
